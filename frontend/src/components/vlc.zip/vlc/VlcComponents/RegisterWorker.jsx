export default function RegisterWorker(){

    
    return(
       <h4>Registration form component</h4>
    );
}