export default function Profile(){
    return(
        <h4>welcome to Profile</h4>
    );
}